export interface ProcessingResultDTO {
  message?: string;
  success?: boolean;
  [key: string]: any;
}
