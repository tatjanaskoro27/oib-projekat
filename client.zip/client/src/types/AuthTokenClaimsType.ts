export type AuthTokenClaimsType = {
  id: number;
  username: string;
  role: string;
};