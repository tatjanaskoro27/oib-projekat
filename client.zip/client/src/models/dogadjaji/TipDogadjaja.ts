export type TipDogadjaja = "INFO" | "WARNING" | "ERROR";
