export interface PerfumeDTO {
  id: number;
  name: string;
}
