export interface LoginUserDTO {
    username: string;
    password: string;
}