export enum PlantStatus {
  PLANTED = "planted",
  HARVESTED = "harvested",
  PROCESSED = "processed",
}
