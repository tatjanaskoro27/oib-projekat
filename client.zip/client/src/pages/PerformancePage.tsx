import { useContext, useEffect } from "react";
import AuthContext from "../contexts/AuthContext";

export const PerformancePage = () => {
  const auth = useContext(AuthContext);

  console.log("TOKEN:", auth?.token);
console.log("AUTH KEYS:", auth ? Object.keys(auth as any) : null);


 useEffect(() => {
  if (!auth?.token) return;

  fetch(import.meta.env.VITE_GATEWAY_URL + "/performance/izvestaji", {
    headers: { Authorization: "Bearer " + auth.token },
  })
    .then((r) => console.log("STATUS:", r.status))
    .catch(console.error);
}, [auth?.token]);



  return (
    <div style={{ padding: 40 }}>
      <h1>Analiza performansi</h1>
      <p>Ako vidiš ovo, stranica se renderuje ✅</p>
    </div>
  );
};
