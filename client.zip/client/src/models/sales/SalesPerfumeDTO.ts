export type SalesPerfumeDTO = {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  available: boolean;
};
