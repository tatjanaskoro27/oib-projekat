export enum UserRole {
  ADMIN = "ADMIN",
  SELLER = "SELLER",
}
